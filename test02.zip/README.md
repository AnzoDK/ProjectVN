# ProjectVN
### Build Status
#### Dev<br> ![](https://travis-ci.com/AnzoDK/ProjectVN.svg?branch=dev)
#### Master<br>![](https://travis-ci.com/AnzoDK/ProjectVN.svg?branch=master) 
<br>
A visual novel created using RPEngine
